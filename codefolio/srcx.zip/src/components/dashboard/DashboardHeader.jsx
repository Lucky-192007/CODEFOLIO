import { usePortfolio } from "../../context/PortfolioContext";

function DashboardHeader() {
  const { theme } = usePortfolio();

  return (
    <div className="mt-8 transition-colors duration-305">
      <h2 className={`text-2xl font-black tracking-tight ${
        theme === "dark" ? "text-slate-100" : "text-slate-900"
      }`}>
        Dashboard Overview
      </h2>

      <p className={`text-sm mt-1.5 ${
        theme === "dark" ? "text-slate-400" : "text-gray-500"
      }`}>
        Track your portfolio setup completions, links, and project status.
      </p>
    </div>
  );
}

export default DashboardHeader;
