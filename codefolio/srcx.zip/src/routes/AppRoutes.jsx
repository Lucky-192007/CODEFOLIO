import { Routes, Route } from "react-router-dom";
import PortfolioPage from "../pages/PortfolioPage";
import Dashboard from "../pages/Dashboard";
import Profile from "../pages/Profile";
import Projects from "../pages/Projects";
import Skills from "../pages/Skills";
import Theme from "../pages/Theme";
import Preview from "../pages/Preview";

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/projects" element={<Projects />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/theme" element={<Theme />} />
      <Route path="/preview" element={<Preview />} />
      <Route path="/portfolio" element={<PortfolioPage />} />
    </Routes>
  );
}

export default AppRoutes;