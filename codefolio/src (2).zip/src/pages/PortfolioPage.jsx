import { useEffect } from "react";
import { usePortfolio } from "../context/PortfolioContext";
import MinimalTemplate from "../templates/MinimalTemplate";
import CyberpunkTemplate from "../templates/CyberpunkTemplate";
import CorporateTemplate from "../templates/CorporateTemplate";

function PortfolioPage() {
  const { templateId, incrementViews } = usePortfolio();

  useEffect(() => {
    // Increment visitor count when the live portfolio page or preview is loaded
    incrementViews();
  }, [incrementViews]);

  const templateMap = {
    minimal: MinimalTemplate,
    cyberpunk: CyberpunkTemplate,
    corporate: CorporateTemplate,
  };
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { usePortfolio } from "../context/PortfolioContext";
import MinimalTemplate from "../templates/MinimalTemplate";
import CyberpunkTemplate from "../templates/CyberpunkTemplate";
import CorporateTemplate from "../templates/CorporateTemplate";
import API from "../services/api"; // Using your custom Axios instance

function PortfolioPage({ isPublic = false }) {
  const { username } = useParams();
  const contextData = usePortfolio(); // Read current dashboard state

  // Local state containers for public viewers
  const [publicData, setPublicData] = useState(null);
  const [loading, setLoading] = useState(isPublic);
  const [error, setError] = useState(null);

  useEffect(() => {
    // If it's the dashboard context variant, track analytic views normally
    if (!isPublic) {
      contextData.incrementViews();
      return;
    }

    const fetchPublicPortfolio = async () => {
      try {
        setLoading(true);
        // Assumes your backend endpoint is setup like: GET /api/auth/public/:username
        // (Adjust this string matching your backend route if necessary)
        const response = await API.get(`/auth/public/${username}`);
        setPublicData(response.data.user); 
      } catch (err) {
        console.error("Public fetch failed", err);
        setError("Portfolio not found or failed to load.");
      } finally {
        setLoading(false);
      }
    };

    fetchPublicPortfolio();
  }, [isPublic, username]);

  // Loading indicator for public link parsing
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white font-mono">
        <p className="animate-pulse text-purple-400 text-lg">⚡ Retrieving Developer Portfolio...</p>
      </div>
    );
  }

  // Error boundary page
  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-slate-300 font-sans p-4 text-center">
        <h1 className="text-4xl font-black text-rose-500 mb-2">404</h1>
        <p className="text-lg font-semibold">{error}</p>
        <a href="/" className="mt-4 px-4 py-2 bg-purple-600 rounded-xl text-white text-sm font-bold shadow hover:bg-purple-700 transition">
          Return Home
        </a>
      </div>
    );
  }

  // Choose where to direct profile fields based on the page context
  // (Provides backward compatibility for your preview templates!)
  const templateId = isPublic ? (publicData?.templateId || "minimal") : contextData.templateId;
  
  const finalProfile = isPublic ? {
    fullName: publicData?.fullName,
    title: publicData?.title,
    experience: publicData?.experience,
    location: publicData?.location,
    bio: publicData?.bio,
    github: publicData?.githubUrl || publicData?.github,
    linkedin: publicData?.linkedinUrl || publicData?.linkedin,
    website: publicData?.websiteUrl || publicData?.website,
    photo: publicData?.photo,
  } : contextData.profile;

  const finalProjects = isPublic ? (publicData?.projects || []) : contextData.projects;
  const finalSkills = isPublic ? (publicData?.skills || []) : contextData.skills;

  const templateMap = {
    minimal: MinimalTemplate,
    cyberpunk: CyberpunkTemplate,
    corporate: CorporateTemplate,
  };

  const PortfolioLayout = templateMap[templateId] || MinimalTemplate;

  // Render template passing computed properties manually down into your structural viewports
  return (
    <PortfolioLayout 
      profile={finalProfile} 
      projects={finalProjects} 
      skills={finalSkills} 
    />
  );
}

export default PortfolioPage;
  const PortfolioLayout =
    templateMap[templateId] || MinimalTemplate;

  return <PortfolioLayout />;
}

export default PortfolioPage;
