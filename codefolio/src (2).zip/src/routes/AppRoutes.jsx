import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext"; 
import AuthPage from "../pages/AuthPage";        
import LandingPage from "../pages/LandingPage";   
import PortfolioPage from "../pages/PortfolioPage";
import Dashboard from "../pages/Dashboard";
import Profile from "../pages/Profile";
import Projects from "../pages/Projects";
import Skills from "../pages/Skills";
import Theme from "../pages/Theme";
import Preview from "../pages/Preview";
import ResetPasswordPage from "../pages/ResetPasswordPage";

const ProtectedRoute = ({ children }) => {
  const { user } = useAuth();
  return user ? children : <Navigate to="/auth" replace />;
};

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />

      <Route 
        path="/auth" 
        element={user ? <Navigate to="/dashboard" replace /> : <AuthPage />} 
      />

      {/* Protected Workspace Layout Routes */}
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="/projects" element={<ProtectedRoute><Projects /></ProtectedRoute>} />
      <Route path="/skills" element={<ProtectedRoute><Skills /></ProtectedRoute>} />
      <Route path="/theme" element={<ProtectedRoute><Theme /></ProtectedRoute>} />
      <Route path="/preview" element={<ProtectedRoute><Preview /></ProtectedRoute>} />
      <Route path="/portfolio" element={<ProtectedRoute><PortfolioPage /></ProtectedRoute>} />
      <Route path="/reset-password/:token" element={<ResetPasswordPage />} />

      {/* ◄--- NEW: Public Portfolio Route (Checks usernames dynamically) */}
      <Route path="/:username" element={<PortfolioPage isPublic={true} />} />

      {/* Catch-all fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default AppRoutes;